INSERT INTO ACCOUNT (id, owner, code, overdraft_allowed) VALUES
    (0, 'Test', '0000', false),
    (1, 'Test1', '1234', true);