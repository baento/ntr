INSERT INTO PRODUCT (id, brand, price) VALUES 
    (1, 'Honor', 430),
    (2, 'Apple', 1002),
    (3, 'Samsung', 740),
    (4, 'Blackberry', 248),
    (5, 'Huawei', 573);